/* window.onload = function() {
    alert("test2")
}; */

window.addEventListener("load", function() {
    alert("test2");
});