/*
window.onload = function() {
    alert("test1")
};
*/

window.addEventListener("load", function() {
    alert("test1");
});