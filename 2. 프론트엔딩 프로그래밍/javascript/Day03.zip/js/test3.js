/* window.onload = function() {
    alert("test3")
}; */

window.addEventListener("load", function() {
    alert("test3");
});